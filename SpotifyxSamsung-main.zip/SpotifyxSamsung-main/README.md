Working 08 Feb 2023

# Spotify Samsung Validation Apk
![IMG_20230124_222400_1](https://user-images.githubusercontent.com/115182304/214334875-bc95ac66-814e-40d4-b0e6-468bcc271208.jpg)

here : https://drive.google.com/drive/folders/1-8F4L_XVreVYlSte7XQ1W9kY8gERKgph



# Cara penggunaan

Termux - Android (recommended version 0.117)

1. pkg upgrade && update
2. pkg install git
3. pkg install php
4. termux-setup-storage
5. git clone https://github.com/agathasangkara/SpotifyxSamsung
6. cd spotifytools
7. php index.php

# Preview
![IMG_20230124_220902_1](https://user-images.githubusercontent.com/115182304/214331697-c6d57f64-5045-4b2d-9fcb-58ff830adaa9.jpg)

1. Mengambil Cookie Browser Chrome(Login)
2. Mengambil Auth Bearer App
3. Daftar dan Validate Samsung Galaxy Series

# Validate
![IMG_20230124_222518_1](https://user-images.githubusercontent.com/115182304/214335191-b7e38295-6bbe-4bdb-a39a-d45442d4758a.jpg)

1. Jalankan Scrip dan pilih Nomor 3
2. Tunggu hinggah selesai, jika anda menggunakan termux maka otomatis akan pergi ke browser dan login menggunakan akun yang berhasil dibuat oleh ditools
3. Bayar - Done.
